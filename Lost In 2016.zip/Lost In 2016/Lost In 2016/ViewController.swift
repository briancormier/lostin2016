//
//  ViewController.swift
//  Lost In 2016
//
//  Created by Cormier Brian on 1/20/17.
//  Copyright © 2017 Cormier Brian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var artists:[String] = ["bowie", "cohen", "george", "jones", "prince"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var count = 0
        
        for artist in artists {
            
            let album = AlbumCover(artist: artist, position: count)
            view.addSubview(album)
            
            let tap = UITapGestureRecognizer (target: self, action: #selector(showDetail(_:)))
            album.addGestureRecognizer(tap)
            
            count += 1
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    func showDetail(_ sender:UITapGestureRecognizer){
        
        
    let detailViewController = DetailViewController()
    
    let itemTapped = sender.view as! AlbumCover
    detailViewController.mainImageView.image = itemTapped.image
        
    self.navigationController?.pushViewController(detailViewController, animated: true)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

