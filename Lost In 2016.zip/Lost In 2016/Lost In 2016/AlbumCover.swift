//
//  AlbumCover.swift
//  Lost In 2016
//
//  Created by Cormier Brian on 1/20/17.
//  Copyright © 2017 Cormier Brian. All rights reserved.
//

import UIKit

class AlbumCover: UIImageView {
    
    var artist:String = ""
    var postion:Int = 0
    init(artist:String, position:Int){
        let frame = CGRect(x: 20, y: 90 + (160 * position), width: 150, height: 150)
        super.init(frame: frame)
        isUserInteractionEnabled = true
        image = UIImage(named: artist)
        alpha = 0
        UIView.animate(withDuration: 2 , delay: TimeInterval(position), options: .curveEaseOut, animations: {
            self.alpha = 1
        }
            , completion: nil)
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implimented")
    
    }
    

}
