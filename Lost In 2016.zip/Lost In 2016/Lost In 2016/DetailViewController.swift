//
//  DetailViewController.swift
//  Lost In 2016
//
//  Created by Cormier Brian on 1/20/17.
//  Copyright © 2017 Cormier Brian. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    var mainImageView:UIImageView = UIImageView(frame: CGRect(x: 10, y: 60, width: 400, height: 400))


    override func viewDidLoad() {
        
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
        view.addSubview(mainImageView)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
